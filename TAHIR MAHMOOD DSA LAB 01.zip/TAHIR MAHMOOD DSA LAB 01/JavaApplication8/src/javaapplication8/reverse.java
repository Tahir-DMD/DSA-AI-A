package javaapplication8;

public class reverse {
    public static void main(String[] args) {
      
        int[] a = {1,3,5,7,9};
        for(int i = a.length-1; i>=0; i--){
            System.out.print(a[i]+" ");
        }
    }
}
